import "./nvad.css"

export default function Navtas (){

    return(
        <>
            <div className="wwss">
                <div className="jjdd">
                    <div className="Ino">
                    INNOSPHERE
                    </div>
                    LEARN
                </div>
            </div>
        </>
    )
}